# John Apollos — Personal Portfolio Website

A fast, responsive, and accessible personal portfolio site showcasing projects, skills, and background.  
This is a multi-page site built with clean, semantic **HTML**, modern **CSS**, and vanilla **JavaScript**.  
Deployed on **Netlify**.

---

## Features

- **Multipage Structure:** Separate pages for Home, About, and Contact for improved navigation and SEO.  
- **Modern UI/UX:** Dark theme, glassmorphism accents, micro-interactions, and polished hover/focus states.  
- **Responsive Layout:** Mobile-first with CSS Grid and Flexbox for seamless viewing on any device.  
- **Accessible Semantics:** Landmarks, alt text, keyboard-friendly modals, and reduced motion-friendly interactions.  
- **Lightweight Stack:** No frameworks; just HTML, CSS, and minimal JS.  
- **Project Modals:** Click cards or "Details" to open descriptive modals.  
- **Contact Form:** Formspree-ready (client-side fetch with graceful error states).  
- **SEO & Social:** Meta tags, OpenGraph/Twitter cards, and Person JSON-LD schema.  
- **Analytics:** Optional Plausible script (privacy-friendly).  

---

## Tech Stack

- **HTML5** for structure and semantics.  
- **CSS3** for layout, theming, and animations.  
- **Vanilla JavaScript** for modals, form handling, and scroll reveals.  
- **Netlify** for hosting and SSL.  
- **Optional:** Formspree for contact form submissions, Plausible for analytics.  

---

## Live Demo

- Portfolio: [https://johnapollosportfolio.netlify.app/](https://johnapollosportfolio.netlify.app/)
