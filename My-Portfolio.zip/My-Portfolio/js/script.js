// =================================================================
// Part 3: Code Organization - Modular JS
// =================================================================

document.addEventListener("DOMContentLoaded", () => {
  // Shared functionality across all pages

  // --- Mobile Navigation Toggle ---
  const navToggle = document.querySelector('.nav-toggle');
  const navLinks = document.querySelector('.nav-links');

  if (navToggle) {
    navToggle.addEventListener('click', () => {
      navLinks.classList.toggle('active');
    });
  }

  // --- Reveal on Scroll (Intersection Observer) ---
  const revealables = document.querySelectorAll(".reveal");
  const observer = new IntersectionObserver(
    (entries, observer) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible");
          observer.unobserve(entry.target); // Stop observing once visible
        }
      });
    },
    { threshold: 0.1 }
  );
  revealables.forEach((el) => observer.observe(el));

  // =================================================================
  // Part 2: JavaScript Functions - Page-Specific Logic
  // =================================================================

  // --- Contact Form Logic (for contact.html) ---
  const contactForm = document.getElementById("contact-form");
  if (contactForm) {
    const status = document.getElementById("form-status");
    const submitBtn = document.getElementById("submit-btn");

    contactForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      const data = new FormData(contactForm);

      submitBtn.disabled = true;
      submitBtn.textContent = "⏳ Sending...";

      try {
        const response = await fetch(contactForm.action, {
          method: contactForm.method,
          body: data,
          headers: { 'Accept': 'application/json' }
        });

        if (response.ok) {
          status.textContent = "✅ Message sent successfully!";
          status.className = "success";
          contactForm.reset();
        } else {
          const responseData = await response.json();
          if (responseData.hasOwnProperty('errors')) {
            status.textContent = responseData.errors.map(error => error.message).join(", ");
          } else {
            status.textContent = "❌ Oops! Something went wrong.";
          }
          status.className = "error";
        }
      } catch (err) {
        status.textContent = "❌ Network error. Please try again later.";
        status.className = "error";
      } finally {
        submitBtn.disabled = false;
        submitBtn.textContent = "Send Message";
      }
    });
  }

  // --- Project Modals Logic (for projects.html) ---
  const modalOpenButtons = document.querySelectorAll(".modal-open");
  const modals = document.querySelectorAll(".modal");

  if (modals.length > 0) {
    function openModalById(id) {
      const modal = document.querySelector(id);
      if (modal) {
        modal.classList.add("open");
        document.body.style.overflow = 'hidden';
      }
    }

    function closeModal(modal) {
      modal.classList.remove("open");
      document.body.style.overflow = '';
    }

    modalOpenButtons.forEach((btn) =>
      btn.addEventListener("click", (e) => {
        const card = e.currentTarget.closest(".project-card");
        const target = card && card.getAttribute("data-modal-target");
        if (target) openModalById(target);
      })
    );

    modals.forEach((modal) => {
      modal.addEventListener("click", (e) => {
        if (e.target.classList.contains("modal") || e.target.closest(".modal-close")) {
          closeModal(modal);
        }
      });
      document.addEventListener("keydown", (e) => {
        if (e.key === "Escape" && modal.classList.contains("open")) {
          closeModal(modal);
        }
      });
    });
  }
});